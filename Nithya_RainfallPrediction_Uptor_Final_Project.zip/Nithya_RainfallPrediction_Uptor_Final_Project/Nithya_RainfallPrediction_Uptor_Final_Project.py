import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler, LabelEncoder
import matplotlib.pyplot as plt
import seaborn as sns
from imblearn.over_sampling import SMOTE
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, roc_auc_score, confusion_matrix
from sklearn.decomposition import PCA
from collections import Counter
import pickle

#DATA LOADING & PREPROCESSING
# load the dataset to a pandas dataframe
data = pd.read_csv("Nithya_RainfallPrediction_Uptor_Final_Project.csv")
print(data.head())
print (data.shape)
print (data.tail)
print (data.describe)
print("Data Info:")
data.info()
print(data.columns)

# remove extra  spaces in all columns
data.columns = data.columns.str.strip()
print(data.columns)

#Drop the "day" column since it's not needed for the model
data = data.drop(columns=["day"])
print(data.head())

# checking the number of missing values
print(data.isnull().sum())

# handle missing values
data["winddirection"] = data["winddirection"].fillna(data["winddirection"].mode()[0])
data["windspeed"] = data["windspeed"].fillna(data["windspeed"].median())

# checking the number of missing values
print(data.isnull().sum())

# Encode the target column ("Rainfall") from 'yes'/'no' to 1/0
label_encoder = LabelEncoder()
data['rainfall'] = label_encoder.fit_transform(data['rainfall'])# 'yes' -> 1, 'no' -> 0
print (data['rainfall'].head())

#EXPLORATORY DATA ANALYSIS
print (data.shape)

# setting plot style for all the plots
sns.set(style="whitegrid")
data.describe()

print (data.columns)

for i, column in enumerate(['pressure', 'maxtemp', 'temparature', 'mintemp', 'dewpoint', 'humidity','cloud', 'sunshine', 'windspeed'], 1):
  plt.subplot(3, 3, i)
  sns.histplot(data[column], kde=True)
  plt.title(f"Distribution of {column}")

plt.tight_layout()
plt.show()

plt.figure(figsize=(6, 4))
sns.countplot(x="rainfall", data=data)
plt.title("Distribution of Rainfall")
plt.show()

# correlation matrix
plt.figure(figsize=(10, 8))
sns.heatmap(data.corr(), annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Correlation heatmap")
plt.show()

#Box plot
plt.figure(figsize=(15, 10))

for i, column in enumerate(['pressure', 'maxtemp', 'temparature', 'mintemp', 'dewpoint', 'humidity','cloud', 'sunshine', 'windspeed'], 1):
  plt.subplot(3, 3, i)
  sns.boxplot(data[column])
  plt.title(f"Boxplot of {column}")

plt.tight_layout()
plt.show()

#calculating outliers percentage
numerical_columns = ['pressure', 'maxtemp', 'temparature', 'mintemp', 'dewpoint', 'humidity', 'cloud', 'sunshine',
                     'windspeed']


# Function to calculate outlier percentage for each numerical column
def outlier_percentage(data, columns):
  outlier_percentages = {}

  for col in columns:
    # Calculate Q1 (25th percentile) and Q3 (75th percentile)
    Q1 = data[col].quantile(0.25)
    Q3 = data[col].quantile(0.75)

    # Calculate the IQR (Interquartile Range)
    IQR = Q3 - Q1

    # Calculate the lower and upper bounds for outliers
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR

    # Identify outliers (values outside the bounds)
    outliers = data[(data[col] < lower_bound) | (data[col] > upper_bound)]

    # Calculate the percentage of outliers
    outlier_percentage = (len(outliers) / len(data)) * 100

    # Store the result
    outlier_percentages[col] = outlier_percentage

  return outlier_percentages

outlier_percentages = outlier_percentage(data, numerical_columns)

# Display the outlier percentages for each numerical column
for col, percentage in outlier_percentages.items():
  print(f"Outlier percentage for {col}: {percentage:.2f}%")


# Define the columns you want to treat for outliers
columns_to_treat = ['humidity', 'windspeed', 'dewpoint', 'cloud']

#Capping (Winsorization) method for treating ouliers
def treat_outliers(data, columns):
  for col in columns:
    # Calculate Q1 (25th percentile) and Q3 (75th percentile)
    Q1 = data[col].quantile(0.25)
    Q3 = data[col].quantile(0.75)

    # Calculate the IQR (Interquartile Range)
    IQR = Q3 - Q1

    # Calculate the lower and upper bounds for outliers
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR

    # Remove outliers (values outside the bounds)
    data = data[(data[col] >= lower_bound) & (data[col] <= upper_bound)]

  return data


# Apply outlier treatment on the selected columns
data_cleaned = treat_outliers(data, columns_to_treat)

# Check the cleaned data
print(data_cleaned.head())


# Modify IQR rule to use a more aggressive approach (3 * IQR instead of 1.5 * IQR)
def treat_outliers(data, columns, multiplier=3):
  for col in columns:
    Q1 = data[col].quantile(0.25)
    Q3 = data[col].quantile(0.75)
    IQR = Q3 - Q1

    lower_bound = Q1 - multiplier * IQR
    upper_bound = Q3 + multiplier * IQR

    data = data[(data[col] >= lower_bound) & (data[col] <= upper_bound)]

  return data


# Reapply outlier treatment with the new, more aggressive rule
data_cleaned = treat_outliers(data, columns_to_treat, multiplier=3)

#REchecking for outlier percentage

def outlier_percentage(data_cleaned, columns):
  outlier_percentages = {}

  for col in columns:
    # Calculate Q1 (25th percentile) and Q3 (75th percentile)
    Q1 = data_cleaned[col].quantile(0.25)
    Q3 = data_cleaned[col].quantile(0.75)

    # Calculate the IQR (Interquartile Range)
    IQR = Q3 - Q1

    # Calculate the lower and upper bounds for outliers
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR

    # Identify outliers (values outside the bounds)
    outliers = data_cleaned[(data_cleaned[col] < lower_bound) | (data_cleaned[col] > upper_bound)]

    # Calculate the percentage of outliers
    outlier_percentage = (len(outliers) / len(data)) * 100

    # Store the result
    outlier_percentages[col] = outlier_percentage

  return outlier_percentages

outlier_percentages = outlier_percentage(data_cleaned, numerical_columns)

# Display the outlier percentages for each numerical column
for col, percentage in outlier_percentages.items():
  print(f"Outlier percentage for {col}: {percentage:.2f}%")

#Preprocessing
  X = data_cleaned.drop('rainfall', axis=1)  # Independent features
  y = data_cleaned['rainfall']  # Target column

  # Handle missing values if any (fill with mean)
  X.fillna(X.mean(), inplace=True)

  # Splitting data into training and testing sets
  X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Standardizing the data (important for PCA and many models)
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

 #Handling class imbalance using SMOTE
smote = SMOTE(random_state=42)
X_train_resampled, y_train_resampled = smote.fit_resample(X_train_scaled, y_train)

#Dimensionality Reduction using PCA
pca = PCA(n_components=0.95)  # Retaining 95% of the variance
X_train_pca = pca.fit_transform(X_train_resampled)
X_test_pca = pca.transform(X_test_scaled)

# Check the shape of the transformed data
print("Training data shape after PCA:", X_train_pca.shape)
print("Test data shape after PCA:", X_test_pca.shape)


#Train a Random Forest model
rf_model = RandomForestClassifier(class_weight='balanced', random_state=42)

# Hyperparameter tuning with GridSearchCV (example)
param_grid = {
    'n_estimators': [100, 200, 300],
    'max_depth': [None, 10, 20],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4]
}

grid_search = GridSearchCV(estimator=rf_model, param_grid=param_grid, cv=5, n_jobs=-1, verbose=2)
grid_search.fit(X_train_pca, y_train_resampled)

# Get best parameters
best_rf_model = grid_search.best_estimator_


# Model Evaluation
y_pred = best_rf_model.predict(X_test_pca)

# Classification Report
print("Classification Report:")
print(classification_report(y_test, y_pred))

# Cross-validation score
cv_scores = cross_val_score(best_rf_model, X_train_pca, y_train_resampled, cv=5)
print("Cross-validation scores:", cv_scores)
print("Average Cross-validation score:", np.mean(cv_scores))

# ROC AUC score
roc_auc = roc_auc_score(y_test, y_pred)
print(f"ROC AUC Score: {roc_auc:.2f}")

#Threshold Tuning for ROC AUC Improvement
#Predict probabilities
y_prob = best_rf_model.predict_proba(X_test_pca)[:, 1]  # Get probabilities for class 1

# Vary the decision threshold to improve ROC AUC
from sklearn.metrics import roc_curve

# Find the optimal threshold
fpr, tpr, thresholds = roc_curve(y_test, y_prob)
optimal_idx = np.argmax(tpr - fpr)  # Find index where tpr - fpr is maximum
optimal_threshold = thresholds[optimal_idx]
print(f"Optimal Decision Threshold: {optimal_threshold}")

# Step 7: Model Evaluation with Threshold Tuning
# Predict probabilities (we will use the optimized threshold)
y_prob = best_rf_model.predict_proba(X_test_pca)[:, 1]  # Get probabilities for class 1

# Make predictions based on the optimal threshold
y_pred_optimal = (y_prob >= optimal_threshold).astype(int)

# Classification Report
print("Classification Report (after threshold tuning):")
print(classification_report(y_test, y_pred_optimal))

# Confusion Matrix
conf_matrix = confusion_matrix(y_test, y_pred_optimal)
print("Confusion Matrix:")
print(conf_matrix)

# Cross-validation score on test set
cv_scores = cross_val_score(best_rf_model, X_test_pca, y_test, cv=5)
print("Cross-validation scores on test set:", cv_scores)
print("Average Cross-validation score on test set:", np.mean(cv_scores))

# ROC AUC score on the test set
roc_auc_test = roc_auc_score(y_test, y_pred_optimal)
print(f"Optimized ROC AUC Score on Test Set: {roc_auc_test:.2f}")

 #Classification Report
print("Classification Report (after threshold tuning):")
print(classification_report(y_test, y_pred_optimal))

# Confusion Matrix
conf_matrix = confusion_matrix(y_test, y_pred_optimal)
print("Confusion Matrix:")
print(conf_matrix)

# ROC Curve and AUC Score
from sklearn.metrics import roc_curve, auc
fpr, tpr, thresholds = roc_curve(y_test, y_prob)
roc_auc = auc(fpr, tpr)

# Plot ROC Curve
plt.figure()
plt.plot(fpr, tpr, color='darkorange', lw=2, label='ROC curve (area = %0.2f)' % roc_auc)
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic (ROC) Curve')
plt.legend(loc="lower right")
plt.show()

# Make new predictions based on the optimal threshold
y_pred_optimal = (y_prob >= optimal_threshold).astype(int)
roc_auc_optimal = roc_auc_score(y_test, y_pred_optimal)
print(f"Optimized ROC AUC Score: {roc_auc_optimal:.2f}")

print(f"Columns in training data: {X.columns.tolist()}")

#Save the Model with Pickle
with open('rainfall_model.pkl', 'wb') as f:
    pickle.dump(best_rf_model, f)

with open('scaler.pkl', 'wb') as f:
    pickle.dump(scaler, f)

with open('pca_model.pkl', 'wb') as f:
    pickle.dump(pca, f)

#MODEL PREDICTION
# Step 1: Load the model, scaler, and PCA transformation
with open('rainfall_model.pkl', 'rb') as f:
    loaded_model = pickle.load(f)

with open('scaler.pkl', 'rb') as f:
    loaded_scaler = pickle.load(f)

with open('pca_model.pkl', 'rb') as f:
    loaded_pca = pickle.load(f)

    # Step 2: Prepare new data (example: new input data)
new_data = pd.DataFrame({
  'pressure': [1015],
  'maxtemp': [30],
  'temparature': [25],
  'mintemp': [20],
  'dewpoint': [18],
  'humidity': [75],
  'cloud': [10],
  'sunshine': [5],
  'winddirection': [270],
  'windspeed': [12],
})

# Step 3: Preprocess new data
# You should perform the same preprocessing steps that were applied to the training data
new_data_scaled = loaded_scaler.transform(new_data)  # Standardize the new data

# Step 4: Apply PCA transformation to the new data
new_data_pca = loaded_pca.transform(new_data_scaled)  # Reduce dimensions using PCA

# Step 5: Make prediction using the loaded model
prediction = loaded_model.predict(new_data_pca)

# Convert numeric prediction back to categorical (if necessary)
prediction_label = "Rain" if prediction[0] == 1 else "No Rain"
print(f"Prediction for the new data: {prediction_label}")

































